package com.gl.service;

import com.gl.To.Student;
import com.gl.repository.StudentRepo;

public class StudentService {
	
	StudentRepo sr=new StudentRepo();
	
	public Student login(String name,String pass)
	{
		return sr.findUser(name,pass);
	}

}
