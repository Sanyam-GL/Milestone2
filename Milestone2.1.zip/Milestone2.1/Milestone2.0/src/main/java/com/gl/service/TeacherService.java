package com.gl.service;


import com.gl.To.Teacher;

import com.gl.repository.TeacherRepo;

public class TeacherService {
	
	TeacherRepo sr=new TeacherRepo();
	
	public Teacher login(String name,String pass)
	{
		return sr.findUser(name,pass);
	}

}
