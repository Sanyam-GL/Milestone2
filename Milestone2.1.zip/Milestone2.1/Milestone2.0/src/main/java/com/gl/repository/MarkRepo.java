package com.gl.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.gl.To.Marks;
import com.gl.To.Student;
import com.gl.database.Database;

public class MarkRepo {
	
	public List<Marks> getAllStudent()
	{
		List<Marks> student=new ArrayList<Marks>();
		Marks marks=new Marks();
		Connection conn = Database.getConnection();
		try {

			PreparedStatement statement = conn
					.prepareStatement("select * from marks");

			
			
			

			ResultSet resultSet = statement.executeQuery();
			

			while (resultSet.next()) {

				int  id = resultSet.getInt(1);
				
				int phy = resultSet.getInt(2);
				
				int chem = resultSet.getInt(3);
				
				int math = resultSet.getInt(4);
				
				
				
				student.add(new Marks(id,phy,chem,math));
			}
		} catch (Exception e) {
			System.out.println("inside catch of addStudent() of StudentRepository");
			e.printStackTrace();
		}
		
		return student;
	}
			
	}


