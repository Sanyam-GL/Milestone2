package com.gl.To;

public class Principal {

	public Principal() {
		
	}
	public Principal(String name, String pass) {
		super();
		this.name = name;
		this.pass = pass;
	}
	private String name;
	private String pass;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
}
