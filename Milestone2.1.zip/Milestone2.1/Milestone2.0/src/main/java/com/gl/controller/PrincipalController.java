package com.gl.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gl.To.Principal;
import com.gl.To.Student;
import com.gl.service.PrincipalService;
import com.gl.service.StudentService;







@WebServlet("/principal")
public class PrincipalController extends HttpServlet {
	
       
	PrincipalService ps=new PrincipalService();
	Principal principal=null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");
		
		RequestDispatcher dispatcher = null;

		switch (action) {
		case "register":

			

			break;

		case "login":
			
			String name = request.getParameter("student_name");
			String pass = request.getParameter("student_pass");
			

			System.out.println(name + ", " + pass);
			
			principal = ps.login(name, pass);
			
			
			if(principal != null) {
				
				dispatcher = request.getRequestDispatcher("principalWelcome.jsp");

				dispatcher.forward(request, response);
			}
			else {
				
				request.setAttribute("errorMessage", "Wrong Credentials, please try again!!");
				
				dispatcher = request.getRequestDispatcher("index.jsp");

				dispatcher.forward(request, response);
			}

			break;

		default:
			break;
		}
	}


}
