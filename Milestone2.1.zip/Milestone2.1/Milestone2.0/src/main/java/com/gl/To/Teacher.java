package com.gl.To;

public class Teacher {
	
	public Teacher() {
		
	}
	
	public Teacher(int id, String name, String pass, String subject, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.pass = pass;
		this.subject = subject;
		this.salary = salary;
	}
	private int id;
	private String name;
	private String pass;
	private String subject;
	private int salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}

}
