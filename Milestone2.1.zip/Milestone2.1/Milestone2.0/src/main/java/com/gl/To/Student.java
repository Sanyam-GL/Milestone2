package com.gl.To;

public class Student {
	
	
	private int id;
	private String name;
	private String pass;
	private String standard;
	
public Student() {
		
	}
	
	public Student(int id, String name, String pass, String standard) {
		super();
		this.id = id;
		this.name = name;
		this.pass = pass;
		this.standard = standard;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", pass=" + pass + ", standard=" + standard + "]";
	}
	

}
