package com.gl.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.gl.To.Principal;
import com.gl.database.Database;

public class PrincipalRepo {

	


	
		Connection conn = Database.getConnection();
		public Principal findUser(String username, String password) {
			Principal principal = null;

			try {

				PreparedStatement statement = conn
						.prepareStatement("select * from principal where principal_name = ? and principal_password = ?");

				statement.setString(1, username);
				statement.setString(2, password);
				
				

				ResultSet resultSet = statement.executeQuery();
				

				if (resultSet.next()) {

					
					
					String name = resultSet.getString(1);
					
					String pass = resultSet.getString(2);
					
					
					
					
					
					return new Principal(name, pass);
					
					
					
				}
			} catch (Exception e) {
				System.out.println("inside catch of addPrincipal() of StudentRepository");
				e.printStackTrace();
			}
			
			return principal;
		}
		
		

	}



