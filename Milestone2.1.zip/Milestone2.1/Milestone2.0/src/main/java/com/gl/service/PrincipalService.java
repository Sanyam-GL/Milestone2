package com.gl.service;

import com.gl.To.Principal;
import com.gl.To.Student;
import com.gl.repository.PrincipalRepo;
import com.gl.repository.StudentRepo;

public class PrincipalService {

PrincipalRepo pr=new PrincipalRepo();
	
	public Principal login(String name,String pass)
	{
		return pr.findUser(name,pass);
	}
}
