package com.gl.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class Database {
	
public static Connection getConnection() {
		
		Connection connection = null;
		
			try {
				
				Class.forName("com.mysql.cj.jdbc.Driver");

				connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/mile2", "root", "root");
				System.out.println("connected......");
			}
			
			catch (Exception e) {
				System.out.println("inside getConnection catch");
				e.printStackTrace();
			}
			return connection;	
		}

}
