package com.gl.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gl.To.Principal;
import com.gl.To.Student;
import com.gl.To.Teacher;
import com.gl.service.PrincipalService;
import com.gl.service.StudentService;
import com.gl.service.TeacherService;

@WebServlet("/student")
public class StudentServlet extends HttpServlet {

	StudentService stu_service = new StudentService();
	TeacherService tea_service = new TeacherService();
	PrincipalService ps = new PrincipalService();
	Student student = null;
	Teacher teacher = null;
	Principal principal = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");
		String role = request.getParameter("role");
		int crole = Integer.parseInt(role);
		RequestDispatcher dispatcher = null;

		switch (action) {
		case "register":

			break;

		case "login":

			String name = request.getParameter("student_name");
			String pass = request.getParameter("student_pass");

			System.out.println(name + ", " + pass);
			switch (crole) {
			case 0:
				student = stu_service.login(name, pass);

				if (student != null) {

					dispatcher = request.getRequestDispatcher("studentWelcome.jsp");

					dispatcher.forward(request, response);
				} else {

					request.setAttribute("errorMessage", "Wrong Credentials, please try again!!");

					dispatcher = request.getRequestDispatcher("index.jsp");

					dispatcher.forward(request, response);
				}
				break;
			case 1:
				teacher = tea_service.login(name, pass);

				if (teacher != null) {

					dispatcher = request.getRequestDispatcher("teacherWelcome.jsp");

					dispatcher.forward(request, response);
				} else {

					request.setAttribute("errorMessage", "Wrong Credentials, please try again!!");

					dispatcher = request.getRequestDispatcher("index.jsp");

					dispatcher.forward(request, response);
				}
			case 2:
				principal = ps.login(name, pass);

				if (principal != null) {

					dispatcher = request.getRequestDispatcher("principalWelcome.jsp");

					dispatcher.forward(request, response);
				} else {

					request.setAttribute("errorMessage", "Wrong Credentials, please try again!!");

					dispatcher = request.getRequestDispatcher("index.jsp");

					dispatcher.forward(request, response);
			}

			break;

		default:
			break;
		}
	}
	}
}
