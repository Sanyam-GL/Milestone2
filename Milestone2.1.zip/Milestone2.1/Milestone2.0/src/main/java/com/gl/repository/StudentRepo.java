package com.gl.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.gl.To.Marks;
import com.gl.To.Student;

import com.gl.database.Database;


public class StudentRepo {
	Connection conn = Database.getConnection();
	public Student findUser(String username, String password) {
		Student student = null;

		try {

			PreparedStatement statement = conn
					.prepareStatement("select * from students where stu_name = ? and stu_password = ?");

			statement.setString(1, username);
			statement.setString(2, password);
			
			

			ResultSet resultSet = statement.executeQuery();
			

			if (resultSet.next()) {

				int  id = resultSet.getInt(1);
				
				String name = resultSet.getString(2);
				
				String pass = resultSet.getString(3);
				
				String standard = resultSet.getString(4);
				
				
				
				return new Student(id,name, pass, standard);
				
				
				
			}
		} catch (Exception e) {
			System.out.println("inside catch of addStudent() of StudentRepository");
			e.printStackTrace();
		}
		
		return student;
	}
	
	public List<Student> getAllStudent()
	{
		List<Student> student=new ArrayList<>();
		Student s=new Student();
		Connection conn = Database.getConnection();
		try {

			PreparedStatement statement = conn
					.prepareStatement("select * from students");

			
			
			

			ResultSet resultSet = statement.executeQuery();
			

			while (resultSet.next()) {

				int  id = resultSet.getInt(1);
				
				String name=resultSet.getString(2);
				String pass=resultSet.getString(3);
				String standard=resultSet.getString(4);
				
				
				
				student.add(new Student(id,name,pass,standard));
			}
		} catch (Exception e) {
			System.out.println("inside catch of addStudent() of StudentRepository");
			e.printStackTrace();
		}
		
		return student;
	}

}
