package com.gl.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.gl.To.Teacher;
import com.gl.database.Database;

public class TeacherRepo {
	
		Connection conn = Database.getConnection();
		public Teacher findUser(String username, String password) {
			Teacher student = null;

			try {

				PreparedStatement statement = conn
						.prepareStatement("select * from teacher where teacher_name = ? and teacher_password = ?");

				statement.setString(1, username);
				statement.setString(2, password);
				
				

				ResultSet resultSet = statement.executeQuery();
				

				if (resultSet.next()) {

					int  id = resultSet.getInt(1);
					
					String name = resultSet.getString(2);
					
					String pass = resultSet.getString(3);
					
					String subject = resultSet.getString(4);
					
					int salary =resultSet.getInt(5);
					
					
					
					return new Teacher(id,name, pass, subject,salary);
					
					
					
				}
			} catch (Exception e) {
				System.out.println("inside catch of addTeacher() of StudentRepository");
				e.printStackTrace();
			}
			
			return student;
		}

	}


