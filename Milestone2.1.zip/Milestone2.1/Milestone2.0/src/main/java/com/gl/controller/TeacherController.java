package com.gl.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gl.To.Student;
import com.gl.service.StudentService;







@WebServlet("/teacher")
public class TeacherController extends HttpServlet {
	
       
	StudentService stu_service=new StudentService();
	Student student=null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");
		
		RequestDispatcher dispatcher = null;

		switch (action) {
		case "register":

			

			break;

		case "login":
			
			String name = request.getParameter("student_name");
			String pass = request.getParameter("student_pass");
			

			System.out.println(name + ", " + pass);
			
			student = stu_service.login(name, pass);
			
			
			if(student != null) {
				
				dispatcher = request.getRequestDispatcher("studentWelcome.jsp");

				dispatcher.forward(request, response);
			}
			else {
				
				request.setAttribute("errorMessage", "Wrong Credentials, please try again!!");
				
				dispatcher = request.getRequestDispatcher("index.jsp");

				dispatcher.forward(request, response);
			}

			break;

		default:
			break;
		}
	}


}
